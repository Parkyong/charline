//
//  MainView1.h
//  PLayoutTest
//
//  Created by 朴勇 on 16/3/31.
//  Copyright © 2016年 ParkYong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppleTurnOffView : UIView
/*
 * 初始化
 * @prama  multiplier 屏幕比例
 */
- (instancetype)initWithMultiplier:(CGFloat)multiplier withButtonSize:(CGSize)size;
/*
 * 添加试图
 * @prama 要添加的试图
 */
- (void)addShowView:(UIView *)view;
/*
 * 添加左边按钮的图片
 * @prama 要添加的图片
 */
- (void)setLeftButtonImage:(UIImage *)image;
/*
 * 更改右边试图Y颜色
 * @prama 要更改的颜色
 */
- (void)setRightViewBackground:(UIColor *)color;
@end
