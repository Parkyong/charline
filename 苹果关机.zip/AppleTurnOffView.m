//
//  MainView1.m
//  PLayoutTest
//
//  Created by 朴勇 on 16/3/31.
//  Copyright © 2016年 ParkYong. All rights reserved.
//

#import "AppleTurnOffView.h"
#import "PureLayout.h"
#import <CoreFoundation/CoreFoundation.h>
@interface AppleTurnOffView ()
//试图
@property (nonatomic, strong) UIView *leftButton;
@property (nonatomic, strong) UIView *rigthView;
@property (nonatomic, strong) UIImageView *headImage;
//本地使用参数
@property (nonatomic, assign) CGSize buttonSize;
@property (nonatomic, assign) CGFloat heigth;
@property (nonatomic, strong) NSArray *hideViewConstraints;
@property (nonatomic, strong) NSArray *showViewConstraints;
@property (nonatomic, assign) CGFloat first_x;
@property (nonatomic, strong) NSLayoutConstraint *widthConstraint;
@property (nonatomic, strong) UIView *tempView;
@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, assign) CGFloat multiplier;
//@property (nonatomic, copy)
@end

@implementation AppleTurnOffView
- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initialize];
    }
    return self;
}

#pragma mark 添加试图
- (void)initialize{
    self.isSelected = NO;
    [self addSubview:self.leftButton];
    [self addSubview:self.rigthView];
    [self.leftButton addSubview:self.headImage];
    
    [self.headImage autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
    
    self.hideViewConstraints = [NSLayoutConstraint autoCreateAndInstallConstraints:^{
        [self.leftButton autoSetDimensionsToSize:self.buttonSize];
        [self.leftButton autoPinEdgeToSuperviewEdge:ALEdgeBottom];

        [self.rigthView autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftButton];
        [self.rigthView autoPinEdgeToSuperviewEdge:ALEdgeRight];
        [self.rigthView autoPinEdgeToSuperviewEdge:ALEdgeBottom];
        [self.rigthView autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.leftButton];
    }];

    self.showViewConstraints = [NSLayoutConstraint autoCreateAndInstallConstraints:^{
        [self.leftButton autoSetDimensionsToSize:self.buttonSize];
        [self.leftButton autoPinEdgeToSuperviewEdge:ALEdgeBottom];
        
        [self.rigthView autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftButton];
        [self.rigthView autoPinEdgeToSuperviewEdge:ALEdgeRight];
        [self.rigthView autoPinEdgeToSuperviewEdge:ALEdgeBottom];
        [self.rigthView autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.leftButton];
        self.widthConstraint = [self.rigthView autoSetDimension:ALDimensionWidth toSize:[UIScreen mainScreen].bounds.size.width*self.multiplier];
    }];
}

- (void)updateConstraints{
    if (self.isSelected) {
        [self.hideViewConstraints autoRemoveConstraints];
        [self.showViewConstraints autoInstallConstraints];
        self.widthConstraint.constant = [UIScreen mainScreen].bounds.size.width*self.multiplier;
        self.tempView.hidden = NO;
    }else{
        [self.showViewConstraints autoRemoveConstraints];
        [self.hideViewConstraints autoInstallConstraints];
        self.tempView.hidden = YES;
    }
    [super updateConstraints];
}

#pragma mark    点击事件
- (void)clickLeftButton:(UIButton *)sender{
    self.isSelected = YES;
    [self animationAction];
}

#pragma mark    拖拽事件
- (void)panViewAction:(UIPanGestureRecognizer *)panGR{
    CGPoint point  = [panGR locationInView:self.leftButton];
    CGFloat offset = 0.0f;
    CGFloat temp   = 0.0f;
    if (panGR.state == UIGestureRecognizerStateBegan) {
        self.first_x = point.x;
    }else if(panGR.state == UIGestureRecognizerStateChanged){
        if (self.widthConstraint.constant > [UIScreen mainScreen].bounds.size.width *self.multiplier) {
            return;
        }else{
            offset = self.first_x - point.x;
            temp =  self.widthConstraint.constant + offset;
            if (temp < 0 ||
                [UIScreen mainScreen].bounds.size.width *self.multiplier - self.widthConstraint.constant > 20)
            {
                self.isSelected = NO;
                [self animationAction];
            }else{
                self.widthConstraint.constant += offset;
            }
        }
    }
}

#pragma mark    动画
- (void)animationAction{
    [self setNeedsUpdateConstraints];
    [self updateConstraintsIfNeeded];
    
    [UIView animateWithDuration:1.0
                          delay:0.0
         usingSpringWithDamping:1
          initialSpringVelocity:0
                        options:0
                     animations:^{
                         [self layoutIfNeeded]; // this is what actually causes the views to animate to their new layout
                     }
                     completion:nil];
}

#pragma mark   - 添加行为
#pragma mark   - 添加试图
- (void)addShowView:(UIView *)view{
    self.tempView = view;
    self.tempView.hidden = NO;
    [self.rigthView addSubview:view];
    [view autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
}

#pragma mark   - 添加leftImage
- (void)setLeftButtonImage:(UIImage *)image{
    self.headImage.image = image;
}

#pragma mark    初始化
- (instancetype)initWithMultiplier:(CGFloat)multiplier withButtonSize:(CGSize)size{
    _multiplier = multiplier;
    _buttonSize = size;
    return [self initWithFrame:[UIScreen mainScreen].bounds];
}

#pragma mark    更改背景颜色
- (void)setRightViewBackground:(UIColor *)color{
    self.rigthView.backgroundColor = color;
}

#pragma mark    懒加载对象
- (UIView *)leftButton{
    if (_leftButton == nil) {
        _leftButton = [UIView newAutoLayoutView];
        _leftButton.layer.cornerRadius = _buttonSize.height/2;
        _leftButton.backgroundColor = [UIColor redColor];//test
        [_leftButton addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickLeftButton:)]];
        [_leftButton addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panViewAction:)]];
        
    }
    return _leftButton;
}

- (UIView *)rigthView{
    if (_rigthView == nil) {
        _rigthView = [UIView newAutoLayoutView];
    }
    return _rigthView;
}

- (UIImageView *)headImage{
    if (_headImage == nil) {
        _headImage = [UIImageView newAutoLayoutView];
        _headImage.contentMode = UIViewContentModeScaleAspectFill;
        _headImage.userInteractionEnabled = YES;
        _headImage.layer.cornerRadius = _buttonSize.height/2.0f;
    }
    return _headImage;
}
@end
