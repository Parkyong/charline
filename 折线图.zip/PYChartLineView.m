//
//  PYChartLineView.m
//  PYChartLine
//
//  Created by 朴勇 on 16/5/23.
//  Copyright © 2016年 EnNew. All rights reserved.
//

#import "PYChartLineView.h"
#define RGBColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:a]
#define SeperatorColor RGBColor(194,222,242,1)
#define FillColor RGBColor(207,233,251,1)
#define LineColor RGBColor(167,195,228,1)
@implementation LineData
@end
@interface PYChartLineView ()
/**<x轴长度*/
@property (nonatomic, assign) CGFloat xLineWidth;
/**<y轴长度*/
@property (nonatomic, assign) CGFloat yLineHeigth;
/**<起点数组*/
@property (nonatomic, strong) NSArray *startPointContainer;
/**<线条数组*/
@property (nonatomic, strong) NSMutableArray *lineArray;
/**<点数组*/
@property (nonatomic, strong) NSMutableArray *pointers;
/**<分割线起点数组*/
@property (nonatomic, strong) NSMutableArray *seperators;
@end
@implementation PYChartLineView
- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setParameters];
    }
    return self;
}

#pragma mark    设置参数
- (void)setParameters{
    self.backgroundColor= [UIColor whiteColor];
    _seperatorLineSpace = 10.0f;
    _seperatorLineCount = 20;
    _xyLineWidth        = 3.0f;
    _yTitleWidth        = 30.0f;
    _maxValue           = 1000;
    _lineWidth          = 3.0f;
    _yTitleFont         = [UIFont systemFontOfSize:12];
    _fillColor          = FillColor;
    _seperatorLineColor = SeperatorColor;
    _lineColor          = LineColor;
    _xyLineColor = [UIColor blackColor];
    _edgeInsets = UIEdgeInsetsMake(20.0, 20.0, 60.0, 20.0);
}

#pragma mark    获取xy轴Point
- (NSArray *)getXYLinePoint:(CGRect)rect{
    LineData *xdata = [LineData new];
    xdata.startPoint = CGPointMake(_edgeInsets.left+_yTitleWidth, rect.size.height -_edgeInsets.bottom);
    xdata.endPoint = CGPointMake(rect.size.width -_edgeInsets.right, rect.size.height -_edgeInsets.bottom);
    
    LineData *ydata = [LineData new];
    ydata.startPoint = CGPointMake(_edgeInsets.left+_yTitleWidth, rect.size.height -_edgeInsets.bottom);
    ydata.endPoint = CGPointMake(_edgeInsets.left+_yTitleWidth, _edgeInsets.top);
    
    _xLineWidth = rect.size.width - _edgeInsets.left - _edgeInsets.right - _yTitleWidth;
    _yLineHeigth = rect.size.height - _edgeInsets.top - _edgeInsets.bottom;
    _startPointContainer = @[xdata, ydata];
    return _startPointContainer;
}

#pragma mark    绘制xy轴
- (void)drawXYLineWithPointContainer:(NSArray *)xyPointArray withLineColor:(UIColor *)color{
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:[[xyPointArray firstObject] startPoint]];
    [path addLineToPoint:[[xyPointArray firstObject] endPoint]];
    [path moveToPoint:[[xyPointArray objectAtIndex:1] startPoint]];
    [path addLineToPoint:[[xyPointArray objectAtIndex:1] endPoint]];
    path.lineWidth = _xyLineWidth;
    [color set];
    [path stroke];
}

#pragma mark    获取分割线点
- (NSArray *)getYLinePointers{
    _seperators = [NSMutableArray array];
    for (int i = 0; i < _values.count+1; i++) {
      CGFloat y = _yLineHeigth / (_values.count+1)*i;
        NSMutableArray *linePointer = [NSMutableArray array];
        CGFloat xRowWidth = _xLineWidth / _seperatorLineCount;;
        for (int j = 0; j < _seperatorLineCount; j++) {
            LineData *data = [LineData new];
            data.startPoint = CGPointMake(j*xRowWidth+_yTitleWidth+_edgeInsets.left, y+_edgeInsets.top);
            data.endPoint = CGPointMake((j+1)*xRowWidth+_yTitleWidth+_edgeInsets.left-_seperatorLineSpace, y+_edgeInsets.top);
            [linePointer addObject:data];
        }
        [_seperators addObject:linePointer];
    }
    return _seperators;
}

#pragma mark    绘制分割线
- (void)drawSeperatorLineWithPointerContainer:(NSArray *)pointerContainer
                                withLineColor:(UIColor *)color{
    UIBezierPath *path = [UIBezierPath bezierPath];
    for (NSArray *itemArray in pointerContainer) {
        for (LineData *data in itemArray) {
            [path moveToPoint:[data startPoint]];
            [path addLineToPoint:[data endPoint]];
        }
    }
    [color set];
    [path stroke];
}

#pragma mark    获取分布线的点
- (NSArray *)getPointerArray{
    _pointers  = [NSMutableArray array];
    _lineArray = [NSMutableArray array];
    NSMutableArray *returnArray  = [NSMutableArray array];
    
    CGFloat yUnit = _yLineHeigth/_maxValue;
    CGFloat xWidth = _xLineWidth/_xLineTitles.count;
    for (int i = 0; i < _values.count; i++) {
        NSString *item =  [_values objectAtIndex:i];
        CGFloat x = _yTitleWidth+_edgeInsets.left+xWidth*i;
        CGFloat y = _yLineHeigth - [item floatValue] *yUnit+_edgeInsets.top;
        CGPoint point = CGPointMake(x, y);
        NSValue *pointValue = [NSValue valueWithCGPoint:point];
        [_pointers addObject:pointValue];
    }
    
    LineData *firstData = nil;
    LineData *finalData = nil;
    for (int i = 0; i < _pointers.count-1; i++) {
        LineData *data = [LineData new];
        if (i == 0) {
            firstData = data;
        }
        data.startPoint = [[_pointers objectAtIndex:i] CGPointValue];
        data.endPoint = [[_pointers objectAtIndex:i+1] CGPointValue];
        [_lineArray addObject:data];
        finalData = data;
    }
    
    //闭环开始点
    LineData *startData  = [LineData new];
    CGPoint startPoint = [[_startPointContainer firstObject] startPoint];
    startPoint = CGPointMake(startPoint.x+_xyLineWidth/2, startPoint.y-_xyLineWidth/2);
    startData.startPoint = startPoint;
    CGPoint endPoint =  firstData.startPoint;
    endPoint = CGPointMake(endPoint.x+_xyLineWidth/2, endPoint.y-_xyLineWidth/2);
    startData.endPoint   = endPoint;

    //闭环结束前一点
    CGPoint preEndPoint = [[_startPointContainer lastObject] startPoint];
    LineData *preEndData  = [LineData new];
    preEndData.startPoint = finalData.endPoint;
    preEndData.endPoint   = CGPointMake(finalData.endPoint.x+_xyLineWidth/2, preEndPoint.y-_xyLineWidth/2);
    
    //闭环结束点
    LineData *endData = [LineData new];
    endData.startPoint = preEndData.endPoint;
    endData.endPoint   = startPoint;
    
    [returnArray addObject:startData];
    [returnArray addObjectsFromArray:_lineArray];
    [returnArray addObject:preEndData];
    return returnArray;
}

#pragma mark    闭环填充颜色
- (void)drawCircleLine:(NSArray *)pointerContainer
          withFillColor:(UIColor *)fillColor{
    UIBezierPath *path = [UIBezierPath bezierPath];
    for (int i = 0; i < pointerContainer.count; i++) {
        LineData *data = [pointerContainer objectAtIndex:i];
        if (i==0) {
            [path moveToPoint:data.startPoint];
        }
        [path addLineToPoint:data.endPoint];
        if (i == pointerContainer.count-1) {
            [[UIColor clearColor] setStroke];
        }
    }
    [fillColor setFill];
    [path fill];
    [path stroke];
}

#pragma mark    绘制线
- (void)drawLineWithLineColor:(UIColor*)lineColor{
    UIBezierPath *path = [UIBezierPath bezierPath];
    for (int i = 0; i < _pointers.count; i++) {
        NSValue *pointValue = [_pointers objectAtIndex:i];
        CGPoint point = [pointValue CGPointValue];
        if (i == 0) {
            [path moveToPoint:CGPointMake(point.x, point.y)];
        }else{
        [path addLineToPoint:CGPointMake(point.x, point.y)];
        }
    }
    path.lineWidth = _lineWidth;
    [lineColor setStroke];
    [path stroke];
}

#pragma mark    绘制y轴title
- (void)drawYTitles{
    for (int i = 0; i < _seperators.count; i++) {
        NSString *title = [NSString stringWithFormat:@"%.f", (_maxValue/_seperators.count)*(_seperators.count-i)];
        NSArray *itemArray = [_seperators objectAtIndex:i];
        LineData *itemLineData = [itemArray firstObject];
        CGPoint itemPoint = itemLineData.startPoint;
        CGSize size = [self sizeWithMaxSize:CGSizeMake(_yTitleWidth, MAXFLOAT) withTitle:title];
        NSDictionary *attrs = @{NSFontAttributeName : _yTitleFont};
        [title drawInRect:CGRectMake(itemPoint.x-_yTitleWidth, itemPoint.y-size.height/2.0f, _yTitleWidth, size.height) withAttributes:attrs];
    }
}

#pragma mark    绘制x轴title
- (void)drawXTitles{
    CGFloat xWidth = _xLineWidth/_xLineTitles.count;
    for (int i = 0; i < _xLineTitles.count; i++) {
        CGFloat x = _yTitleWidth+_edgeInsets.left+xWidth*i;
        LineData *xData = [_startPointContainer firstObject];
        CGFloat y = xData.startPoint.y;
        NSString *title = [_xLineTitles objectAtIndex:i];
        CGSize size = [self sizeWithMaxSize:CGSizeMake(MAXFLOAT, MAXFLOAT) withTitle:title];
        NSDictionary *attrs = @{NSFontAttributeName : _yTitleFont};
        [title drawInRect:CGRectMake(x, y, size.width, size.height) withAttributes:attrs];
    }
}

#pragma mark    代理方法
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self touchKeyPoint:touches withEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self touchKeyPoint:touches withEvent:event];
}

- (void)touchKeyPoint:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint touchPoint = [touch locationInView:self];
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(getXLineData:withYLineData:)]) {
        NSInteger index = (touchPoint.x-_edgeInsets.left-_xyLineWidth)/
                          (_xLineWidth/_xLineTitles.count);
        CGFloat value =_maxValue - (touchPoint.y - _edgeInsets.top)*(_maxValue/_yLineHeigth);
        [self.delegate getXLineData:[_xLineTitles objectAtIndex:index] withYLineData:[NSString stringWithFormat:@"%f",value]];
    }
}

- (void)updateChartLineWithXLineData:(NSArray *)xLinedata
                       withYLineData:(NSArray *)yLineData{
    _xLineTitles = xLinedata;
    _values = yLineData;
    [self setNeedsDisplay];
}

#pragma mark    绘制
- (void)drawRect:(CGRect)rect{
    //绘制xy轴
    [self drawXYLineWithPointContainer:[self getXYLinePoint:rect]
                         withLineColor:_xyLineColor];

    //绘制闭环
    [self drawCircleLine:[self getPointerArray]
           withFillColor:_fillColor];
    
    //绘制分割线
    [self drawSeperatorLineWithPointerContainer:[self getYLinePointers]
                                  withLineColor:_seperatorLineColor];

    //绘制线
    [self drawLineWithLineColor:_lineColor];
    
    //绘制Y标题
    [self drawYTitles];
    
    //绘制x标题
    [self drawXTitles];
    
    //调用父试图绘制
    [super drawRect:rect];
}

#pragma mark    tool
- (CGSize)sizeWithMaxSize:(CGSize)maxSize withTitle:(NSString *)title
{
    NSDictionary *attrs = @{NSFontAttributeName : _yTitleFont};
    return [title boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}
@end
