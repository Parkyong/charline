//
//  PYChartLineView.h
//  PYChartLine
//
//  Created by 朴勇 on 16/5/23.
//  Copyright © 2016年 EnNew. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface LineData : NSObject
/**<两点定一线*/
/**<开始点*/
@property (nonatomic, assign) CGPoint startPoint;
/**<结束点*/
@property (nonatomic, assign) CGPoint endPoint;
@end

@protocol PYChartLineViewDelegate <NSObject>
- (void)getXLineData:(NSString*)xLineData withYLineData:(NSString *)yLineData;
@end
@interface PYChartLineView : UIView
/**<x轴line的标题*/
@property (nonatomic, strong) NSArray *xLineTitles;
/**<y轴line的标题*/
@property (nonatomic, strong) NSArray *values;
/**<y轴标题的宽度*/
@property (nonatomic, assign) CGFloat yTitleWidth;
/**<y轴标题的字体*/
@property (nonatomic, strong) UIFont *yTitleFont;
/**<y轴最大值*/
@property (nonatomic, assign) CGFloat maxValue;
/**<x轴y轴的颜色*/
@property (nonatomic, strong) UIColor *xyLineColor;
/**<x轴y轴的线条的粗细*/
@property (nonatomic, assign) CGFloat xyLineWidth;
/**<分割线间距- - -*/
@property (nonatomic, assign) CGFloat seperatorLineSpace;
/**<分割线个数- - -*/
@property (nonatomic, assign) NSInteger seperatorLineCount;
/**<分割线颜色- - -*/
@property (nonatomic, strong) UIColor *seperatorLineColor;
/**<闭环填充色彩*/
@property (nonatomic, strong) UIColor *fillColor;
/**<主线的颜色*/
@property (nonatomic, strong) UIColor *lineColor;
/**<主线的宽度*/
@property (nonatomic, assign) CGFloat lineWidth;
/**<边距*/
@property (nonatomic, assign) UIEdgeInsets edgeInsets;
/**<代理*/
@property (nonatomic, assign) id <PYChartLineViewDelegate>delegate;

- (void)updateChartLineWithXLineData:(NSArray *)xLinedata withYLineData:(NSArray *)yLineData;
@end
